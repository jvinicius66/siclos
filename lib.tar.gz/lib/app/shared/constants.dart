const String BASE_URL = 'https://fakestoreapi.com';
const String PRODUCT_URL = '/products';
