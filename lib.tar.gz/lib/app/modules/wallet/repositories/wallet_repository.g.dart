// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_repository.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $WalletRepository = BindInject(
  (i) => WalletRepository(),
  singleton: true,
  lazy: true,
);
