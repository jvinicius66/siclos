// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart_repository.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $CartRepository = BindInject(
  (i) => CartRepository(),
  singleton: true,
  lazy: true,
);
