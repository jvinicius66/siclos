// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_list_repository.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $ProductRepository = BindInject(
  (i) => ProductRepository(i<Dio>()),
  singleton: true,
  lazy: true,
);
